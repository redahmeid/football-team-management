__version__ = "1.3.0"

from mergedeep.mergedeep import merge, Strategy

__all__ = ["merge", "Strategy"]
