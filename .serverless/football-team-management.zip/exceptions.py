class AuthError(Exception):
    "Could not log you in"
    pass