import pandas as pd

df = pd.read_excel('u7sFalcons.xlsx', sheet_name='Fixtures')

print(df)